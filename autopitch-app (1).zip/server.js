// Placeholder for backend server code
console.log("Server running...");